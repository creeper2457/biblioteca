import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-VBJUSLWW.js";
import "./chunk-3SAP3AIC.js";
import "./chunk-XD55MQRC.js";
import "./chunk-ELCMXN2K.js";
import "./chunk-XYQXUUIZ.js";
import "./chunk-MRDIM7HM.js";
import "./chunk-PWPZWS66.js";
import "./chunk-YHCV7DAQ.js";
export {
  MatDivider,
  MatDividerModule
};
