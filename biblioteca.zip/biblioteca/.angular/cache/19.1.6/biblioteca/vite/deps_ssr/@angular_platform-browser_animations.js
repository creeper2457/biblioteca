import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-7O7GNHV2.js";
import "./chunk-22UYDJ3B.js";
import "./chunk-T2SQ3ANH.js";
import "./chunk-MRDIM7HM.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-PWPZWS66.js";
import "./chunk-YHCV7DAQ.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
