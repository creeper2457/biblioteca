import {
  MatDivider,
  MatDividerModule
} from "./chunk-YKY33VS6.js";
import "./chunk-DFQR22DH.js";
import "./chunk-7MSRQ37Y.js";
import "./chunk-3MBYO22Y.js";
import "./chunk-UY6RT42O.js";
import "./chunk-KBOAPL3B.js";
import "./chunk-DRCFMEAQ.js";
export {
  MatDivider,
  MatDividerModule
};
