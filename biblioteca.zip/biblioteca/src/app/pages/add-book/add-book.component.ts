import { Component } from '@angular/core';


@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css'],
  standalone:false 
})
export class AddBookComponent {
  newBook = {
    title: '',
    author: '',
    category: ''
  };

  savedBook: any = null;
  bookSaved = false;

  /**
   * Simula el guardado del libro y muestra la información guardada.
   */
  addBook(): void {
    this.savedBook = { ...this.newBook };  // Copiamos el libro actual
    this.bookSaved = true;

    // Limpiamos el formulario
    this.newBook = {
      title: '',
      author: '',
      category: ''
    };

    // Ocultamos el mensaje después de unos segundos (opcional)
    setTimeout(() => (this.bookSaved = false), 3000);
  }
}
