import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  standalone: false,
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent {
  books = [
    { title: 'El Quijote', author: 'Miguel de Cervantes', category: 'Clásicos' },
    { title: 'Cien Años de Soledad', author: 'Gabriel García Márquez', category: 'Realismo Mágico' },
    { title: '1984', author: 'George Orwell', category: 'Distopía' },
    { title: 'Fahrenheit 451', author: 'Ray Bradbury', category: 'Distopía' },
    { title: 'Orgullo y Prejuicio', author: 'Jane Austen', category: 'Romance' },
    { title: 'Matar a un Ruiseñor', author: 'Harper Lee', category: 'Clásicos' },
    // Añade más libros según tus necesidades
  ];

  filteredBooks = this.books; // Inicializa filteredBooks con todos los libros

  // Método para manejar el evento de entrada y filtrar libros
  onInput(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    const query = inputElement.value;
    this.filterBooks(query);
  }

  // Método para filtrar libros
  filterBooks(query: string): void {
    const lowercaseQuery = query.toLowerCase();
    this.filteredBooks = this.books.filter(book =>
      book.title.toLowerCase().includes(lowercaseQuery) ||
      book.author.toLowerCase().includes(lowercaseQuery) ||
      book.category.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Método para limpiar el campo de búsqueda y restablecer la lista de libros
  clearSearch(inputElement: HTMLInputElement): void {
    inputElement.value = '';
    this.filteredBooks = this.books;
  }
}
