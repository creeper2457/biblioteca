import { Component } from '@angular/core';

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.css'],
  standalone:false
})
export class FavoritesComponent {
  favorites = [
    { title: 'El Quijote', author: 'Miguel de Cervantes', category: 'Clásicos' },
    { title: 'Cien Años de Soledad', author: 'Gabriel García Márquez', category: 'Realismo Mágico' }
    // Agrega más libros favoritos aquí
  ];

  /**
   * Elimina un libro de la lista de favoritos.
   * @param book El libro a eliminar.
   */
  removeFavorite(book: any): void {
    this.favorites = this.favorites.filter(fav => fav !== book);
  }
}
