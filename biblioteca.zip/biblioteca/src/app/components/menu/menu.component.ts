import { Component } from '@angular/core';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
  standalone: false
})
export class MenuComponent {
  sidebarItems = [
    { label: 'Inicio', icon: 'home', url: '/main' },
    { label: 'Agregar Libro', icon: 'add', url: '/add-book' },
    { label: 'Favoritos', icon: 'favorite', url: '/favorites' },
    
    { label: 'Acerca de', icon: 'info', url: '/about' }
  ];
}
