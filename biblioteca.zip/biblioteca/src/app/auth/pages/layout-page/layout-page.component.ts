import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-page',
  standalone: false,
  templateUrl: './layout-page.component.html',
  styles: ``
})
export class LayoutPageComponent {
  public sidebarItems = [
    { label: 'Listado de libros', icon: 'label', url: '/list' },
    { label: 'Añadir libro', icon: 'add', url: '/new-heroe' },
    { label: 'Buscar libro', icon: 'search', url: '/search' },
  ];
}
