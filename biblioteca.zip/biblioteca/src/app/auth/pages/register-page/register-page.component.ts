import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-page',
  standalone: false,
  templateUrl: './register-page.component.html',
  styles: ``
})
export class RegisterPageComponent {
  constructor(private router: Router) { }

  onRegister() {
    // Redirigir a la página principal sin realizar validaciones
    this.router.navigate(['/main']);
  }
} 